package com.my.wificar;
  
import java.util.Timer;
import java.util.TimerTask; 
 
import com.my.wificar.R;  
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;
import android.view.GestureDetector;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.GestureDetector.SimpleOnGestureListener;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.view.animation.TranslateAnimation;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AbsoluteLayout;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;
import android.widget.SeekBar.OnSeekBarChangeListener;

public class MyVideo extends Activity implements OnClickListener, SensorEventListener 
{
	private static final String ACTION = "com.my.wificar.action.NEW_FILE";
	private static final String ACTION_FINISH = "com.my.wificar.action.UPLOAD_FINISH";
	
	private Button but_center;
	private Button but_left;
	private Button but_right;
	private Button but_up;
	private Button but_below;
	private Button but_r_speenUp;
	private Button but_l_speenUp;
	private Button but_r_slowDown;
	private Button but_l_slowDown;
	private Button but_menu;
	
	private	TextView title;
	private static int js=0;
//	private URL videoUrl; 

	public static String CameraIp;
	public static String CtrlIp;
	public static String CtrlPort;
	public static boolean Is_Scale;
	private MySurfaceView r;
	public static String stat;
	private SeekBar sb1,sb2,sb3,sb4,sb5,sb6;
	private TextView wendu,shidu,left_zs,right_zs; 
	private int progress_num;
	private Button bt_1,bt_2,bt_3; 
//    private RelativeLayout control;
    
    private SensorManager mSensorManager;  
    private Sensor mSensor; 
    private int mAction = -1;
    private int flag =1;
    private boolean zl_flag=true;
    public static String pre_Action = "0";
    public static String sAction= "0";
    
//    private GestureDetector mDetector; 
    
    
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE); 
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        
        setContentView(R.layout.myvideo);
         
        
        mSensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);  
        mSensor = mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);// TYPE_GRAVITY  
        if (null == mSensorManager) {  
            Log.d("TAG", "deveice not support SensorManager");  
        }  

        mSensorManager.registerListener(this, mSensor,  
                SensorManager.SENSOR_DELAY_NORMAL); 
        
//        mDetector = new GestureDetector(this, new MyGestureListener()); 
        
    	initView();
    	 
		
		Intent intent = getIntent(); 
		CameraIp = intent.getStringExtra("CameraIp");		 
		CtrlIp = intent.getStringExtra("CtrlIp");
		CtrlPort = intent.getStringExtra("CtrlPort");
		Is_Scale = intent.getBooleanExtra("Is_Scale", false);
		r.GetCameraIP(CameraIp);
		r.Is_Scale = Is_Scale;
 
		IntentFilter filter = new IntentFilter(ACTION_FINISH);
		registerReceiver(this.UploadList, filter);
		
		Intent serviceIntent = new Intent();
		serviceIntent.setAction("com.my.wificar.service");
		bindService(serviceIntent, new ServiceConnection() {
			
			public void onServiceDisconnected(ComponentName name) {
				
			}
			
			public void onServiceConnected(ComponentName name, IBinder service) {
				
			}
		}, Context.BIND_AUTO_CREATE);	
		
		UpStat();
	 
	}
	
	
	@Override   
	public boolean onTouchEvent(MotionEvent event) {  

//		   return mDetector.onTouchEvent(event);  
		   
		   
		if (event.getAction() == MotionEvent.ACTION_DOWN) {  
		 
		} else if (event.getAction() == MotionEvent.ACTION_UP) {  
			if(pre_Action.equals("0") && sAction.equals("0")){
	    		 
    		}else if(!pre_Action.equals("0") && sAction.equals("0")){ 
    			sAction = pre_Action; 
    			sendTap("0");
    		}else if(pre_Action.equals("0") && !sAction.equals("0")){
    			String str = sAction;
    			sendTap(str); 
    			sAction = "0"; 
    		} 
		}  
		
		return true;   
	} 
	  
	
	
	
	
	/**
	 * 定时刷新连接状况
	 */
	private void UpStat(){
		 Timer timer = new Timer();  
		 timer.schedule(new TimerTask() { 
			@Override
			public void run() {  
				 sendStat("s");
			}
		 }, 0,3000);
	}
 
	private final BroadcastReceiver UploadList = new BroadcastReceiver() {
		@Override
		public void onReceive(Context context, Intent intent) {
			    String str=intent.getStringExtra("RESULT");
			    
	            if(str.equals("1")){
	            	title.setText("连接成功");
	          //  	Toast.makeText(MainActivity.this, str, 0).show();
	            }
	            if(str.equals("end")){
	            	str="设备连接不上，请退出程序！";
	            	title.setText("连接失败，请退出程序，重新连接！");
//	            	Toast.makeText(MyVideo.this, str, Toast.LENGTH_SHORT).show();
	            }
	            
	            if(str.equals("-1")){
	            	title.setText("连接失败");
	            }
	            if(str.equals("r")){
	            	title.setText("连接失败,按任意键重连");
	            }
	            if(str.equals("-2")){
	            	title.setText("连接失败");
	            }
	            if(str.equals("3")){
	            	js++;
	            	if(js==6){
	            		js=1;
	            	}
	            	String s=repeat(".",js);
	            	title.setText("正在连接"+s);
	            }
	            if(str.equals("s")){ 
	        		try { 
		                String res=intent.getStringExtra("DES"); 
		                String[] dd = res.split("\\&");
		                if(dd[2].length()>8){
		                    stat =  dd[2].substring(8);
			        		 String[] aa = stat.split("\\|");
			        		 if(aa[0]!=null & aa[0].length() > 0)
			        			 wendu.setText("温度:	"+aa[2]);
			        		 if(aa[1]!=null & aa[1].length() > 0)
			        			 shidu.setText("湿度:	"+aa[3]);
			        		 if(aa[2]!=null & aa[2].length() > 0)
			        			 left_zs.setText("右轮转速:	 "+aa[1]);
			        		 if(aa[3]!=null & aa[3].length() > 0)
			        			 right_zs.setText("左轮转速:	"+aa[0]);
		                }
		          
	        		} catch (Exception e) { 
	        			e.printStackTrace();
	        		}
	        		

	            }
		}
	};
	 public static String repeat(String src, int num) {
	        StringBuffer s = new StringBuffer();
	        for (int i = 0; i < num; i++)
	            s.append(src);
	        return s.toString();
	    }
	 
	public void initView() {
        r = (MySurfaceView)findViewById(R.id.mySurfaceViewVideo);
		wendu = (TextView) findViewById(R.id.wendu);
		shidu = (TextView) findViewById(R.id.shidu);
		left_zs = (TextView) findViewById(R.id.left_zs);
		right_zs = (TextView) findViewById(R.id.right_zs);
//    	control = (RelativeLayout) findViewById(R.id.control);
    	title = (TextView) findViewById(R.id.title);
		but_center = (Button) findViewById(R.id.but_center);
		but_left = (Button) findViewById(R.id.but_left);
		but_right = (Button) findViewById(R.id.but_right);
		but_up = (Button) findViewById(R.id.but_up);
		but_below = (Button) findViewById(R.id.but_below);
		but_l_slowDown = (Button) findViewById(R.id.but_l_slowDown);
		but_r_slowDown = (Button) findViewById(R.id.but_r_slowDown);
		but_l_speenUp = (Button) findViewById(R.id.but_l_speenUp);
		but_r_speenUp = (Button) findViewById(R.id.but_r_speenUp); 
		but_menu = (Button) findViewById(R.id.but_menu); 
		
		bt_1 = (Button) findViewById(R.id.but_1);
		bt_2 = (Button) findViewById(R.id.but_2);
		bt_3 = (Button) findViewById(R.id.but_3);
		
		bt_1.setOnClickListener(this);
		bt_2.setOnClickListener(this);
		bt_3.setOnClickListener(this);
		
		but_center.setOnClickListener(this);
		but_left.setOnClickListener(this);
		but_right.setOnClickListener(this);
		but_up.setOnClickListener(this);
		but_below.setOnClickListener(this);
		but_l_slowDown.setOnClickListener(this);
		but_r_slowDown.setOnClickListener(this);
		but_l_speenUp.setOnClickListener(this);
		but_r_speenUp.setOnClickListener(this);
		but_menu.setOnClickListener(this);
		 
		 sb1 = (SeekBar) findViewById(R.id.seekbar1);
	     sb1.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {   
	         public void onStopTrackingTouch(SeekBar seekBar) {  
	        	 send("#1P"+String.valueOf(progress_num));
//	        	 send("0");
	         }   
	         public void onStartTrackingTouch(SeekBar seekBar) { 
	        	 
	         }   
	         public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) { 
	        	 progress_num = progress;	
	        	 
	         }  
	     });  
	     
		 sb2 = (SeekBar) findViewById(R.id.seekbar2);
	     sb2.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {   
	         public void onStopTrackingTouch(SeekBar seekBar) {   
	        	 send("#2P"+String.valueOf(progress_num));
	         }   
	        
	         public void onStartTrackingTouch(SeekBar seekBar) {   
	         }   
	       
	         public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) { 
	        	 progress_num = progress;	
	         }  
	     });  
		 sb3 = (SeekBar) findViewById(R.id.seekbar3);
	     sb3.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {   
	        
	         public void onStopTrackingTouch(SeekBar seekBar) {   
	        	 send("#3P"+String.valueOf(progress_num));
	         }   
	      
	         public void onStartTrackingTouch(SeekBar seekBar) {   
	         }   
	        
	         public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) { 
	        	 progress_num = progress;	
	         }  
	     });  
		 sb4 = (SeekBar) findViewById(R.id.seekbar4);
	     sb4.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {   
	       
	         public void onStopTrackingTouch(SeekBar seekBar) {   
	        	 send("#4P"+String.valueOf(progress_num));
	         }   
	       
	         public void onStartTrackingTouch(SeekBar seekBar) {   
	         }   
	      
	         public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) { 
	        	 progress_num = progress;
	         }  
	     });  
		 sb5 = (SeekBar) findViewById(R.id.seekbar5);
	     sb5.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {   
	       
	         public void onStopTrackingTouch(SeekBar seekBar) {   
	        	 send("#5P"+String.valueOf(progress_num));
	         }   
	      
	         public void onStartTrackingTouch(SeekBar seekBar) {   
	         }   
	     
	         public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) { 
	        	 progress_num = progress;
	         }  
	     });  
		 sb6 = (SeekBar) findViewById(R.id.seekbar6);
	     sb6.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {   
	       
	         public void onStopTrackingTouch(SeekBar seekBar) {  
	        	 send("#6P"+String.valueOf(progress_num));
	         }   
	       
	         public void onStartTrackingTouch(SeekBar seekBar) {   
	         }   
	      
	         public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) { 
	        	 progress_num = progress;
	         }  
	     });  
	}
	
 
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.but_center:
			send("0");
			break;
		case R.id.but_left:
			send("3");
			break;
		case R.id.but_right:
			send("4");
			break;
		case R.id.but_up:
			send("1");
			break;
		case R.id.but_below:
			send("2");
			break;
		case R.id.but_l_speenUp:
			send("6");
			break;
		case R.id.but_r_speenUp:
			send("8");
			break;
		case R.id.but_l_slowDown:
			send("7");
			break;
		case R.id.but_r_slowDown:
			send("9");
			break;
		case R.id.but_menu:
			if(zl_flag){
				zl_flag=false;
				mAction = -1;
        		flag=1;
				but_menu.setBackgroundResource(R.drawable.zl_g);
			}else{
				zl_flag=true;
				but_menu.setBackgroundResource(R.drawable.zl_k);
				mAction = -1;
        		flag=1;
			}
				
				
//			if (control.getVisibility() == View.VISIBLE) {
//				control.setVisibility(View.INVISIBLE);
//				TranslateAnimation animation = null;
//				animation = new TranslateAnimation(0, 0, 0, control.getHeight());				
//				animation.setDuration(control.getHeight());
//				control.startAnimation(animation);
//			} else {
//				control.setVisibility(View.VISIBLE);
//				TranslateAnimation animation = null;
//				animation = new TranslateAnimation(0, 0, control.getHeight(),0);
//				animation.setDuration(control.getHeight());
//				control.startAnimation(animation);
//			}
			
			
			break;
		case R.id.but_1:
			send("#1G");
			break;
		case R.id.but_2:
			send("#2G");
			break;
		case R.id.but_3:
			send("#3G");
		default:
			break;
		}
	}
	
	public void sendTap(String str) {
		pre_Action = str; 
	 
		Intent intentAddFile = new Intent(ACTION);
		intentAddFile.putExtra("TYPE", str);
		sendBroadcast(intentAddFile);
	}
	
	public void send(String str) {
		pre_Action = str; 
		sAction = "0";
		
		Intent intentAddFile = new Intent(ACTION);
		intentAddFile.putExtra("TYPE", str);
		sendBroadcast(intentAddFile);
	}
	
	public void sendStat(String str) { 
		
		Intent intentAddFile = new Intent(ACTION);
		intentAddFile.putExtra("TYPE", str);
		sendBroadcast(intentAddFile);
	}
	
	
	public void onDestroy() 
	{
		super.onDestroy();
		unregisterReceiver(this.UploadList); 
		
		Intent serviceIntent = new Intent();  
        serviceIntent.setAction("com.my.wificar.service"); 
        stopService(serviceIntent); 
	 
	}
	
	
	
	private long exitTime = 0;
	@Override  
    public boolean onKeyDown(int keyCode, KeyEvent event)   
    {  
		 if(keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_DOWN)  
		 {  
		           
		         if((System.currentTimeMillis()-exitTime) > 2500)   
				 {  
					  exitTime = System.currentTimeMillis();  
					  Toast.makeText(getApplicationContext(), "再按一次退出程序！",Toast.LENGTH_SHORT).show();                                  
				 }  
		         else  
		         {  
		             finish();  
		             System.exit(0);  
		         }  
		                   
		         return true;  
		 }  
		 return super.onKeyDown(keyCode, event);  
    }

	  public void onAccuracyChanged(Sensor sensor, int accuracy) {  
		  
	    }  
	  
	    public void onSensorChanged(SensorEvent event) {  
	        if (event.sensor == null) {  
	            return;  
	        }  
	        
	        if(zl_flag){
		        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {  
		        	float x =  event.values[0];  
		        	float y =  event.values[1];  
		        	float z =  event.values[2];  
		            int tmp = -1;
		            
		        	if(z>0){
		        		if(y<1.5 && y>-1.5 && x<-3){
		        			tmp = 1;
		        		}
		        		
		        		if(y<1.5 && y>-1.5 && x>3){
		        			tmp = 2;
		        		}
		        		
		        		if(x<1.5 && x>-1.5 && y<-3){
		        			tmp = 3;
		        		}
		        		
		        		if(x<1.5 && x>-1.5 && y>3){
		        			tmp = 4;
		        		}
		        	 }
		        	 
		        	if(flag == 1 && tmp != -1){
		        		mAction = tmp;
		        		flag=2;
		        		return;
		        	}
		        	 
		        	if(flag == 2 && tmp != -1){
		        		if(mAction == tmp){ 
			        		send(String.valueOf(mAction));
			        		mAction = -1;
			        		flag=1;
		        		}else{
		        			mAction = tmp;
		        		}
		        	}
		        }
		        
	        }

	    }  

	    
	    
	    
	    
	    
//	    public class MyGestureListener extends SimpleOnGestureListener {
//	    	
//	    	private static final String TAG = "MyGestureListener";
//
//	    	public MyGestureListener() {
//	    		
//	    	}
//
//	    	/**
//	    	 * 双击的第二下Touch down时触发 
//	    	 * @param e
//	    	 * @return
//	    	 */
//	    	@Override
//	    	public boolean onDoubleTap(MotionEvent e) {
//	    		Log.i(TAG, "onDoubleTap : " + e.getAction());
//	    		return super.onDoubleTap(e);
//	    	}
//
//	    	/**
//	    	 * 双击的第二下 down和up都会触发，可用e.getAction()区分。
//	    	 * @param e
//	    	 * @return
//	    	 */
//	    	@Override
//	    	public boolean onDoubleTapEvent(MotionEvent e) {
//	    		Log.i(TAG, "onDoubleTapEvent : " + e.getAction());
//	    		return super.onDoubleTapEvent(e);
//	    	}
//
//	    	/**
//	    	 * down时触发 
//	    	 * @param e
//	    	 * @return
//	    	 */
//	    	@Override
//	    	public boolean onDown(MotionEvent e) {
//	    		Log.i(TAG, "onDown : " + e.getAction());
//	    		return super.onDown(e);
//	    	}
//
//	    	/**
//	    	 * Touch了滑动一点距离后，up时触发。
//	    	 * @param e1
//	    	 * @param e2
//	    	 * @param velocityX
//	    	 * @param velocityY
//	    	 * @return
//	    	 */
//	    	@Override
//	    	public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX,
//	    			float velocityY) {
//	    		Log.i(TAG, "onFling e1 : " + e1.getAction() + ", e2 : " + e2.getAction() + ", distanceX : " + velocityX + ", distanceY : " + velocityY);
//	    		return super.onFling(e1, e2, velocityX, velocityY);
//	    	}
//
//	    	/**
//	    	 * Touch了不移动一直 down时触发 
//	    	 * @param e
//	    	 */
//	    	@Override
//	    	public void onLongPress(MotionEvent e) {
//	    		Log.i(TAG, "onLongPress : " + e.getAction());
//	    		super.onLongPress(e);
//	    	}
//
//	    	/**
//	    	 * Touch了滑动时触发。 
//	    	 * @param e1
//	    	 * @param e2
//	    	 * @param distanceX
//	    	 * @param distanceY
//	    	 * @return
//	    	 */
//	    	@Override
//	    	public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX,
//	    			float distanceY) {
//	    		Log.i(TAG, "onScroll e1 : " + e1.getAction() + ", e2 : " + e2.getAction() + ", distanceX : " + distanceX + ", distanceY : " + distanceY);
//	    		return super.onScroll(e1, e2, distanceX, distanceY);
//	    	}
//
//	    	/**
//	    	 * Touch了还没有滑动时触发 
//	    	 * @param e
//	    	 */
//	    	@Override
//	    	public void onShowPress(MotionEvent e) {
//	    		Log.i(TAG, "onShowPress : " + e.getAction());
//	    		super.onShowPress(e);
//	    	}
//
//	    	@Override
//	    	public boolean onSingleTapConfirmed(MotionEvent e) { 
//	    		
//	    		if(pre_Action.equals("0") && sAction.equals("0")){
//	    		 
//	    		}else if(!pre_Action.equals("0") && sAction.equals("0")){
//	    		 
//	    			sAction = pre_Action; 
//	    			sendTap("0");
//	    		}else if(pre_Action.equals("0") && !sAction.equals("0")){
//	    			String str = sAction;
//	    			sendTap(str); 
//	    			sAction = "0"; 
//	    		}
//	    		 
//	    		
//	    		return super.onSingleTapConfirmed(e);
//	    	}
//
//	  
//	    	
//	    	@Override
//	    	public boolean onSingleTapUp(MotionEvent e) {
//	    		Log.i(TAG, "onSingleTapUp : " + e.getAction());
//	    		return super.onSingleTapUp(e);
//	    	}
//	    }
}


