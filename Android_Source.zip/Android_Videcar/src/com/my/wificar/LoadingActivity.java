package com.my.wificar;

import com.my.wificar.R;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;

public class LoadingActivity extends Activity {

//	private static final String ACTION = "com.my.wificar.action.NEW_FILE";
//	private static final String ACTION_FINISH = "com.my.wificar.action.UPLOAD_FINISH";
//	
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_loading);
	 
		
		
		new Thread(){

			@Override
			public void run() {
				try {
					sleep(2000); 
//				 	 send("#5P33");
					Intent intent = new Intent(LoadingActivity.this,MainActivity.class);
					startActivity(intent);
					LoadingActivity.this.finish();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			
		}.start();
	}
	
//	private void send(String str) {
//		Intent intentAddFile = new Intent(ACTION);
//		intentAddFile.putExtra("TYPE", str);
//		sendBroadcast(intentAddFile);
//	}
	
//	private final BroadcastReceiver UploadList = new BroadcastReceiver() {
//		@Override
//		public void onReceive(Context context, Intent intent) {
//			    String str=intent.getStringExtra("RESULT");
//			     
//	            if(str.equals("s")){
//	            	Log.v("1111111111111111111","aaaaaaaaaaaaaaaa");
//	        		try {
//		            	String res=intent.getStringExtra("DES");
//		            	Log.v("1111111111111111111",res);
//
//	        		} catch (Exception e) {
//	        			Log.v("1111111111111111111","eeeeeeeeeeee");
//	        			e.printStackTrace();
//	        		}
//	        	 
//	            }
//		}
//	};
	
}
