/** Automatically generated file. DO NOT MODIFY */
package com.my.wificar;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}